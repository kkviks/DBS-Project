create definer = root@localhost view reception_orderview as
select `dbs_project`.`customer`.`Room_No`                                                     AS `Room_No`,
       `dbs_project`.`room_service`.`Special_Request`                                         AS `Special_Request`,
       `dbs_project`.`room_service`.`Inventories`                                             AS `Inventories`,
       `dbs_project`.`room_service`.`Extra_Charges`                                           AS `Extra_Charges`,
       `dbs_project`.`room_service`.`Service_Date_Time`                                       AS `Service_Date_Time`,
       concat(`dbs_project`.`employee`.`FirstName`, ' ', `dbs_project`.`employee`.`LastName`) AS `BellBoyName`,
       `dbs_project`.`room_service`.`Bell_Boy`                                                AS `Bell_Boy`
from `dbs_project`.`customer`
         join `dbs_project`.`room_service`
         join `dbs_project`.`employee`
where ((`dbs_project`.`customer`.`Customer_ID` = `dbs_project`.`room_service`.`Customer_ID`) and
       (`dbs_project`.`employee`.`E_ID` = `dbs_project`.`room_service`.`Bell_Boy`))
order by `dbs_project`.`customer`.`Room_No`;

