create definer = root@localhost view manager_attendanceview as
select concat(`dbs_project`.`employee`.`FirstName`, ' ', `dbs_project`.`employee`.`LastName`) AS `Name`,
       `dbs_project`.`employee`.`Designation`                                                 AS `Designation`,
       `dbs_project`.`employee`.`E_ID`                                                        AS `E_ID`,
       `dbs_project`.`attendance`.`isPresent`                                                 AS `isPresent`,
       `dbs_project`.`attendance`.`Attendance_Date`                                           AS `Required_Attendance`
from `dbs_project`.`employee`
         join `dbs_project`.`attendance`
where ((`dbs_project`.`employee`.`E_ID` = `dbs_project`.`attendance`.`E_ID`) and
       (0 <> `dbs_project`.`attendance`.`Attendance_Date`));

