create definer = root@localhost view reception_overviewview as
select `dbs_project`.`room`.`Room_No`       AS `Room_No`,
       `dbs_project`.`room`.`Room_Type`     AS `Room_Type`,
       `dbs_project`.`room`.`Availability`  AS `Availability`,
       `dbs_project`.`room_type`.`Beds_Num` AS `Beds_Num`,
       `dbs_project`.`room_type`.`Price`    AS `Price`
from `dbs_project`.`room`
         join `dbs_project`.`room_type`
where (`dbs_project`.`room`.`Room_Type` = `dbs_project`.`room_type`.`Type`)
order by `dbs_project`.`room`.`Availability` desc, `dbs_project`.`room_type`.`Price` desc,
         `dbs_project`.`room`.`Room_No`;

