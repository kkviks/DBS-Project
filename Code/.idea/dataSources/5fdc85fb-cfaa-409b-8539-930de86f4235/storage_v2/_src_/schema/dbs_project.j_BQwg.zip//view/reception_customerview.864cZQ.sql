create definer = root@localhost view reception_customerview as
select `dbs_project`.`customer`.`Room_No`                                                   AS `Room_No`,
       concat(`dbs_project`.`visitor`.`FirstName`, ' ', `dbs_project`.`visitor`.`LastName`) AS `Name`,
       `dbs_project`.`customer`.`Service_Type`                                              AS `Service_Type`,
       `dbs_project`.`customer`.`Occupants_Num`                                             AS `Occupants_Num`,
       `dbs_project`.`customer`.`Arrival`                                                   AS `Arrival`,
       `dbs_project`.`customer`.`Special_Requests`                                          AS `Special_Requests`,
       `dbs_project`.`bill`.`Due`                                                           AS `Due`
from `dbs_project`.`customer`
         join `dbs_project`.`visitor`
         join `dbs_project`.`bill`
where ((`dbs_project`.`customer`.`Visitor_ID` = `dbs_project`.`visitor`.`Visitor_ID`) and
       (`dbs_project`.`bill`.`Bill_ID` = `dbs_project`.`customer`.`Bill_ID`))
order by `dbs_project`.`customer`.`Room_No`;

