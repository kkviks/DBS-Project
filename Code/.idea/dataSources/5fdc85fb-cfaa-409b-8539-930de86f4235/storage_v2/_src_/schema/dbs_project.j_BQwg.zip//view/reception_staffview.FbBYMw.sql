create definer = root@localhost view reception_staffview as
select concat(`dbs_project`.`employee`.`FirstName`, ' ', `dbs_project`.`employee`.`LastName`) AS `Name`,
       `dbs_project`.`employee`.`Designation`                                                 AS `Designation`,
       `dbs_project`.`employee`.`Phone`                                                       AS `Phone`,
       `dbs_project`.`employee`.`Shift`                                                       AS `Shift`,
       `dbs_project`.`attendance`.`isPresent`                                                 AS `Availability`
from `dbs_project`.`employee`
         join `dbs_project`.`attendance`
where (`dbs_project`.`employee`.`E_ID` = `dbs_project`.`attendance`.`E_ID`);

