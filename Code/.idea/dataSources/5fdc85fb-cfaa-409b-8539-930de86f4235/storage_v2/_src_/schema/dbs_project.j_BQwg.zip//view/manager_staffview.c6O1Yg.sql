create definer = root@localhost view manager_staffview as
select concat(`dbs_project`.`employee`.`FirstName`, ' ', `dbs_project`.`employee`.`LastName`) AS `Name`,
       `dbs_project`.`employee`.`Designation`                                                 AS `Designation`,
       `dbs_project`.`employee`.`Phone`                                                       AS `Phone`,
       `dbs_project`.`employee`.`Shift`                                                       AS `Shift`,
       `dbs_project`.`attendance`.`isPresent`                                                 AS `Availability`,
       `dbs_project`.`designation`.`Wage`                                                     AS `Wage`
from `dbs_project`.`employee`
         join `dbs_project`.`attendance`
         join `dbs_project`.`designation`
where ((`dbs_project`.`employee`.`E_ID` = `dbs_project`.`attendance`.`E_ID`) and
       (`dbs_project`.`designation`.`Designation_Name` = `dbs_project`.`employee`.`Designation`));

